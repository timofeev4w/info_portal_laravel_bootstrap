@extends('layouts.main_layout')

@section('css')

@endsection


@section('content')

<div class="row">
    <div class="col-12 text-center">
        <h1 class="text-success info-success">
            Сервис в разработке!
        </h1>
    </div>
</div>

@endsection

@section('js')

{{-- <script src="{{ asset('/js/payment.js') }}"></script> --}}

@endsection