@extends('layouts.main_layout')

@section('content')
    <div class="row text-center">
        <h3>
            Контакты
        </h3>
    </div>

    <div class="row">
        <div class="col">
            <b>Организация:</b> Тимофеев Никита Алексеевич
        </div>
    </div>

    <div class="row">
        <div class="col">
            <b>ИНН:</b> 781717205691
        </div>
    </div>
    
    <div class="row">
        <div class="col">
            <b>Email:</b> support@moidolgi.org
        </div>
    </div>
@endsection