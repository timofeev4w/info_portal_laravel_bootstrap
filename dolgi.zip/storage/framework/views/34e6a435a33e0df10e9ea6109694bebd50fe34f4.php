<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 text-center">
        <div class="info-progress">
            <h1>
                Поиск информации...
            </h1>
            <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">0%</div>
            </div>
        </div>
        
        <div class="info-success d-none">
            <h1 class="text-success">
                Информация найдена!
            </h1>

            <div class="row">
                <div class="col-12 col-md-7">
                    Здесь виджет оплаты...
                </div>
                <div class="col-12 col-md-5 text-start text-secondary">
                    <a href="payment_methods">Платежи</a>
                    <br>
                    <a href="payment_security">Гарантии безопасности онлайн платежей</a>
                    <br>
                    <a href="goods_return">Возврат</a>
                    <br>
                    <a href="personal_policy">Политика обработки персональных данных</a>
                </div>
            </div>
        </div>
        

        
    </div>
    <div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('/js/payment.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nikita/DEVELOP/PHP/dolgi_laravel_composer/resources/views/payment.blade.php ENDPATH**/ ?>