<?php $__env->startSection('content'); ?>

<div class="row text-center">
    <h3>Платежи. Оплата банковской картой онлайн</h3>
    <div class="col">
        На нашем сайте вы можете оплатить товар банковской картой Visa, MasterCard или Мир. После подтверждения выбранного товара откроется защищенное окно со страницей платёжного сервис провайдера ArsenalPay, где Вам необходимо ввести данные Вашей банковской карты. Для дополнительной аутентификации держателя карты используется протокол 3D Secure. Если Ваш банк поддерживает данную технологию, Вы будете перенаправлены на его сервер для дополнительной идентификации. Информацию о правилах и методах дополнительной идентификации уточняйте, пожалуйста, в банке, выдавшем Вам банковскую карту.
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nikita/DEVELOP/PHP/dolgi_laravel_composer/resources/views/payment_methods.blade.php ENDPATH**/ ?>