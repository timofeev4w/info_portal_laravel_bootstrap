<?php $__env->startSection('content'); ?>
    <div class="row text-center">
        <h3>
            Контакты
        </h3>
    </div>

    <div class="row">
        <div class="col">
            <b>Организация:</b> Тимофеев Никита Алексеевич
        </div>
    </div>

    <div class="row">
        <div class="col">
            <b>ИНН:</b> 781717205691
        </div>
    </div>
    
    <div class="row">
        <div class="col">
            <b>Email:</b> support@moidolgi.org
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nikita/DEVELOP/PHP/dolgi_laravel_composer/resources/views/contacts.blade.php ENDPATH**/ ?>