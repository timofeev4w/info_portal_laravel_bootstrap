<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row py-5">
    <div class="col-12 col-md-6 offset-md-3">
        <div class="row mb-3">
            <h2 class="fw-bold text-center">
                Вход
            </h2>
        </div>
        
        <form method="POST" action="login" class="row g-3 needs-validation" novalidate>
            <?php echo csrf_field(); ?>
            <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
            <div class="text-danger mt-0">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <input type="password" class="form-control" id="password" name="password" placeholder="Пароль" value="<?php echo e(old('password')); ?>">
            <div class="text-danger mt-0">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="text-danger mt-0">
                <?php if(isset($noLogin)): ?>
                    <?php echo e($noLogin); ?>

                <?php endif; ?>
            </div>
            

            <button class="btn btn-success btn-send-user-data" type="submit">Войти</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nikita/DEVELOP/PHP/dolgi_laravel_composer/resources/views/login.blade.php ENDPATH**/ ?>